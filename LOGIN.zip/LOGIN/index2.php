<?php require_once 'koneksi.php';?>
<?php
session_start();
include('koneksi.php');
if(isset($_POST['submit']))
		{
			if ($_POST["vercode"] != $_SESSION["vercode"] OR $_SESSION["vercode"]=='')  {
		echo "<script>alert('Incorrect verification code');</script>" ;
	} 
     	else {
		$name=$_POST['username'];
			$email=$_POST['password'];
		$ad="insert into tubes(username,password) values(?,?)";
        $stmt= $mysqli->prepare($ad);
        $stmt->bind_param(ss,$name,$email);
          $stmt->execute();
          $stmt->close();	   
          echo "<script>alert('Data added Successfully');</script>" ;

		    }	
		}
		    ?>
<!DOCTYPE html>
<html>
<head>
	<title>Dongeng Anak</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
<style>
	body{
		margin: 0;
	}
	.header{
		background-color: #2463ad;
		padding: 20px;
		text-align: center;
	}
	*{
		font-family: verdana;
		font-size: 15px;
	}
	.ul{
		margin: 0;
		padding: 0;
		overflow: hidden;
		background-color: #f3f3f3;
		border: 0.5px solid #e7e7e7;
	}
	ul{
		margin: 0;
		padding: 0;
		list-style-type: none;
	}
	li{
		float: left;
	}
	li a{
		display: block;
		color: #666666;
		text-align: center;
		padding: 16px;
		text-decoration: none;
	}
	li a:hover{
		background-color: #008CBA;
		color: white;
	}
	li a.aktif{
		background-color: #008CBA;
		color: white;
	}
	li a, .dropbtn{
		display: block;
		color: #666666;
		text-align: center;
		padding: 16px;
		text-decoration: none;
	}
	li a:hover, .dropdown:hover .dropbtn{
		background-color: #dddddd;
		color: #666666;
	}
	li.dropdown{
		display: block;
	}
	.dropdown-content{
		display: none;
		position: absolute;
		background-color: #f9f9f9;
		min-width: 160px;
		z-index: 1;
	}
	.dropdown-content a{
		color: #666666;
		padding: 12px 16px;
		text-decoration: none;
		display: block;
		text-align: left;

	}
	.dropdown-content a:hover {background-color: #f1f1f1}
	.dropdown: hover .dropdown-content{
		display: block;
	}
	.aktif{
		background-color: #008CBA;
		color: white;
	}
	  .gallery{
  	margin: 30px;
  	border: 1px solid #ccc;
  	float: left;
  	width: 300px;
  	height: 50%;
  }

  .gallery:hover{
  	border: 1px solid #777
  	background-color: yellow;
  }

  .deskripsi{
  	padding: 10px;
  	text-align: center;
  }

  .gallery img{
  	width: 100%;
  	height: auto;
  }
	.footer{
		background-color: #f1f1f1;
		padding: 10px;
		text-align: center;
		clear: both;
	}


</style>
</head>
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
<body>
	<?php 
		if(isset($_GET['pesan'])){
			if($_GET['pesan'] == "salah"){
				echo "<p>Captcha tidak sesuai.</p>";
			}
		}
		?>
		<?php
    if(!isset($_SESSION)){
    	session_start();
	    echo "<center><br/>Maaf sepertinya anda belum Login,silahkan tekan link login dibawah <br/></a><a href='login.php'><center>Login</center></a>";
    }else{
        echo "<center>Selamat Anda Berhasil Login !<br/><a href='logout.php'>Logout</a></center>";
    }
	include 'koneksi.php';
	?>
	<div class="col-12">
	<div class="header">
		<h1><img src="3.svg" width="50%" height="50%"></h1>
		<div class="ul">		
	<ul style="float: left;">
		<li><a href="index.html" class="aktif">Beranda</a></li>
		<li><a href="navigation1.html">Tentang</a></li>
		<li><a href="kontak.html">Kontak</a></li>
		<li class="dropdown">
			<a href="#" class="dropbtn">Kategori</a>
			<div class="dropdown-content">
				<a href="dermayu.html">Cerita Indramayu</a>
				<a href="#">Cerita Legenda</a>
				<a href="#">Cerita Fabel</a>
				<a href="#">Cerita dongeng</a>
				<a href="#">Cerita </a>
			</div>
		</li>
		<li><a href="logout.php"> Logout</a></li>
	</ul>
	<form style="float: right; margin-top: 15px;" action="cari-data.php" method="post">
      <input type="text" placeholder="Search.." name="search">
      <button type="submit">Cari</button>
    </form>
		</div>
	</div>
	<div class="gallery">
		<a href="#">
			<img src="timunmas.jpg">
		</a>
		<div class="deskripsi"><h1>Kisah Timun Mas</h1></div>
		<center><a href="timunmas.html">Read More</a></center>
	</div>

	<div class="gallery">
		<a href="#">
			<img src="jakatarub.jpg">
		</a>
		<div class="deskripsi">Jaka Tarub</div>
		<center><a href="#">Read More</a></center>
	</div>

	<div class="gallery">
		<a href="#">
			<img src="malin.jpg">
		</a>
		<div class="deskripsi">Malin Kundang</div>
		<center><a href="#">Read More</a></center>
	</div>
	</div>

<div class="footer">
		<font color="black">
		<center><p>Jl. Raya Lohbener Lama No.08, Kec.Lohbener, Kab.Indramayu</p>
		<p>Telp (0234) 5746464. Email : ti@polindra@ac.id</p>
		<p>Copyright Jurusan Teknik Informatika 2019. All Rights Reserved.</p></center>
		</font>
	</div>
</div>
</body>
</html>