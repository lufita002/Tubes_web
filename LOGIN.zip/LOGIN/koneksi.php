<?php
$dbhost = 'localhost'; 
$dbuser = 'root'; //ini hanya berlaku di Xampp
$dbpass = ''; //ini hanya berlaku di Xampp
$dbname = 'tubes';

$connect = new mysqli($dbhost,$dbuser,$dbpass,$dbname);
?>