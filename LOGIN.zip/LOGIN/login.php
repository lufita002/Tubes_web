<html>
    <head>
        <title>Form Login</title>
    </head>
     <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <body>
        <div class="container mt-5 w-25">
            <img src="logo.jpg" class="w-75 mx-auto mt-2">
            <div class="card-body">
                <form class="bingkai" action="proseslogin.php" method="POST">
                    <div class="form-group">
                        <input class="form-control" type="text" name="username" placeholder="Masukkan Username" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" name="password" placeholder="Masukkan Password" required>
                    </div>
                    <tr>
                    <td>Verification code :</td>
                        <input type="text" class="form-control1" name="vercode" placeholder="Verification Code" maxlength="5" autocomplete="off" required style="width: 225px; height: 26px;" />&nbsp;
                            <img src="captcha.php">
                    <div class="form-grouph">
                        <input class="btn btn-block btn-primary" type="submit" name="submit" value="Login">
                    </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>

