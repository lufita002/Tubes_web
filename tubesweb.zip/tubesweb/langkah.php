<!DOCTYPE html>
<html lang="en">
<head>
	<title>Dongeng Anak Dermayu</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style>
		body{
			margin:0;
		}
		.header{
			background-color: #f1f1f1;
			padding: 20px;
			text-align: center;
		}
		.navigation{
			overflow: hidden;
			background-color: #03A9F4;
		}
		.navigation a{
			float: left;
			display: block;
			color: #f2f2f2;
			text-align: center;
			padding: 14px 16px;
			text-decoration: none;
		}
		.navigation a:hover{
			background-color: #ddd;
			color: black;
		}
		.dropdown-content{
			display: none;
			position: absolute;
			background-color: #f9f9f9;
			min-width: 160px;
			padding:12px;
			z-index: 1;
		}
		.dropdown:hover .dropdown-content{
			display: block;
		}
		.dropdown{
			position: relative;
			display: inline-block;
		}
		*{
			font-family: verdana;
			font-size: 15px;
		}
		ul{
			list-style-type: none;
			margin:0;
			padding: 0;
			overflow: hidden;
			background-color: #f3f3f3;
			border: 0.5px solid #e7e7e7;
		}
		li{
			float: left;
		}
		li a, .dropbtn{
			display: block;
			color: #666666;
			text-align: center;
			padding: 16px;
			text-decoration: none;
		}
		li a:hover, .dropdown:hover .dropbtn{
			background-color: #dddddd;
			color: #666666;
		}
		li.dropdown{
			display: block;
		}
		.dropdown-content{
			display: none;
			position: absolute;
			background-color: #f9f9f9;
			min-width: 160px;
			z-index: 1;
		}
		.dropdown-content a{
			color: #666666;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			text-align: left;
		}
		.dropdown-content a:hover {background-color: #f1f1f1}
		.dropdown:hover .dropdown-content{
			display: block;
		}
		.aktif{
			background-color: #008cba;
		}
	</style>
</head>
<body>
	<div class="header">
		<h1><img src="3.svg" height="100%" width="50%"></h1>
	</div>
	<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
<div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Dropdown button
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="#">Action</a>
    <a class="dropdown-item" href="#">Another action</a>
    <a class="dropdown-item" href="#">Something else here</a>
  </div>
</div> 	
</body>
</html>